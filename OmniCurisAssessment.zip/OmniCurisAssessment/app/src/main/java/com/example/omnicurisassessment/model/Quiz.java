package com.example.omnicurisassessment.model;

import java.util.ArrayList;
import java.util.List;

public class Quiz {


        public Quiz() {
                questions = new ArrayList<>();
        }

        public ArrayList<com.example.omnicurisassessment.model.Quiz.Questions> questions;

        public static class Questions {
            public String question;
            public String answer;
            public List<com.example.omnicurisassessment.model.Quiz.Questions.Options> options = new ArrayList<>();


            public static class Options {

                public String option1;
                public String option2;
                public String option3;
                public String option4;
            }

        }

}
