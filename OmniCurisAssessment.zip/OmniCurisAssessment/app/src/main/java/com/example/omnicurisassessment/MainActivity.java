package com.example.omnicurisassessment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.example.omnicurisassessment.model.Quiz;
import com.google.gson.Gson;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private LinearLayout linearLayoutButton;
    private LinearLayout linearLayoutQuiz;
    private TextView textViewQuestion;
    private RadioGroup radioGroup;
    private RadioButton radioButton1, radioButton2, radioButton3, radioButton4;
    private Button buttonNext, buttonPrevious;
    private int questionNumber;
    private int resultScore = 0;
    private Quiz quiz;
    private AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        initViews();

    }

    /**
     * Populating  the views to the UI
     */
    private void initViews() {
        quiz = new Gson().fromJson(readJSONFromAsset(), Quiz.class);
        builder = new AlertDialog.Builder(this);
        Button buttonStartQuiz = findViewById(R.id.button_start_quiz);
        buttonPrevious = findViewById(R.id.button_previous);
        buttonNext = findViewById(R.id.button_next);
        buttonStartQuiz.setOnClickListener(this);
        buttonNext.setOnClickListener(this);
        buttonPrevious.setOnClickListener(this);
        textViewQuestion = findViewById(R.id.qusetion);
        linearLayoutButton = findViewById(R.id.layout_button);
        linearLayoutQuiz = findViewById(R.id.quiz_layout);
        radioGroup = findViewById(R.id.radio_group);
        radioButton1 = findViewById(R.id.radio_button1);
        radioButton2 = findViewById(R.id.radio_button2);
        radioButton3 = findViewById(R.id.radio_button3);
        radioButton4 = findViewById(R.id.radio_button4);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup rGroup, int i) {
                if (radioGroup.getCheckedRadioButtonId() != -1) {
                    String selectedValue =
                            ((RadioButton) findViewById(i)).getText().toString();
                    if (selectedValue.equals(quiz.questions.get(questionNumber).answer)) {
                        resultScore++;
                    }
                }
            }
        });
    }

    /**
     * Reading the questions from Json file and parsing it to Quiz model class
     */
    public String readJSONFromAsset() {
        String json;
        try {
            InputStream is = getAssets().open("questions.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button_start_quiz:
                questionNumber = 0;
                showQuizQuestion();
                break;
            case R.id.button_next:
                radioGroup.clearCheck();
                if (buttonNext.getText().equals("Submit")) {
                    String message = String.format("%s %s %s", getResources().getString(R.string.quiz_completed_successfully), getResources().getString(R.string.score), (resultScore / 2));
                    builder.setTitle(message);
                    builder.setCancelable(false)
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    resultScore = 0;
                                    dialog.dismiss();
                                }
                            });
                    linearLayoutButton.setVisibility(View.VISIBLE);
                    linearLayoutQuiz.setVisibility(View.GONE);
                    AlertDialog alert = builder.create();
                    alert.show();
                } else {
                    questionNumber = questionNumber + 1;
                    showQuizQuestion();
                }
                break;
            case R.id.button_previous:
                radioGroup.clearCheck();
                questionNumber = questionNumber - 1;
                showQuizQuestion();
                break;
        }
    }

    /**
     * Showing the questions to the User
     */
    private void showQuizQuestion() {
        linearLayoutButton.setVisibility(View.GONE);
        linearLayoutQuiz.setVisibility(View.VISIBLE);
        if (questionNumber == 0) {
            buttonPrevious.setVisibility(View.GONE);
            buttonNext.setVisibility(View.VISIBLE);
            buttonNext.setText(getResources().getString(R.string.next));
        } else if (questionNumber == 4) {
            buttonPrevious.setVisibility(View.VISIBLE);
            buttonNext.setText(getResources().getString(R.string.submit));
        } else {
            buttonPrevious.setVisibility(View.VISIBLE);
            buttonNext.setVisibility(View.VISIBLE);
        }
        textViewQuestion.setText((quiz.questions.get(questionNumber).question));
        radioButton1.setText(quiz.questions.get(questionNumber).options.get(0).option1);
        radioButton2.setText(quiz.questions.get(questionNumber).options.get(0).option2);
        radioButton3.setText(quiz.questions.get(questionNumber).options.get(0).option3);
        radioButton4.setText(quiz.questions.get(questionNumber).options.get(0).option4);
    }

}
